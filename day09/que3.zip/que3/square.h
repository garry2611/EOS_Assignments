#include<stdio.h>

int peri(int a);

int area_s(int a);

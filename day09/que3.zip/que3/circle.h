#include<stdio.h>

int circumference(int radius);
int area_c(int radius);

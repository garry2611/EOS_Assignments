#include"square.h"

int peri(int a){
    return 4*a;
}

int area_s(int a){
    return a*a; 
}

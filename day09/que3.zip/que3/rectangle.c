#include"rectangle.h"

int perimeter(int l,int b){
    return 2*(l+b);
}

int area_r(int l,int b){
    return l*b;
}

#include<stdio.h>

int perimeter(int l,int b);

int area_r(int l,int b);

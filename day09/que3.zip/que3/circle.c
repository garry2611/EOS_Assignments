#include"circle.h"

//Function Definitions
int circumference(int radius){
    return 2*3.14*radius;
}

int area_c(int radius){
    return 3.14*radius*radius;
}
